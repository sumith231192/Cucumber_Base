package pageObject;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.WaitUtil;

public class HistoricalPage {
	WebDriver driver;
	WaitUtil waitUtil = new WaitUtil();

	public HistoricalPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindAll(@FindBy(xpath = "//button[@role= 'tab']"))
	private List<WebElement> tablist;

	@FindBy(xpath = "//button//span[text()='Payments']")
	private WebElement paymentsTab;
	@FindBy(xpath = "//button//span[text()='EOD Balances']")
	private WebElement EODBalancesTab;

	public void validateTabPresent(String tab) {
		boolean validate = false;
		for (WebElement elemt : tablist) {
			if (elemt.getText().equalsIgnoreCase(tab)) {
				validate = true;
				break;
			}

		}
		assertEquals(validate, true, "The Given Tab valie " + tab + "is displayed as expected");
	}

	public void navigateToPaymentsTab() {
		waitUtil.untilWebElementIsClickable(driver, paymentsTab);
		paymentsTab.click();
	}

	public void navigateToEODBalancesTab() {
		waitUtil.untilWebElementIsClickable(driver, EODBalancesTab);
		EODBalancesTab.click();
	}
}
