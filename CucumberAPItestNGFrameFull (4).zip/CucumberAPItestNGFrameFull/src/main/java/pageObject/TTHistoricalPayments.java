package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.WaitUtil;
import utility.ConfigFileReader;

public class TTHistoricalPayments {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	WaitUtil waitUtil = new WaitUtil();

	// WebDriverWait wb=new WebDriverWait(driver,1000);
	@FindBy(xpath = "//span[text()='Historical")
	private WebElement Historical;
	@FindBy(xpath = "//input[@placeholder='Currency']")
	private WebElement currency;
	@FindBy(xpath = "//input[@placeholder='Search bank account']")
	private WebElement bankAccount;
	// @FindBy(xpath="//label[text()='Date
	// From']//following-sibling::div//input[@class='MuiInputBase-input
	// MuiInput-input MuiInputBase-inputAdornedEnd']']") WebElement fromCalendar;
	@FindBy(xpath = "//div/form/span[5]/div/div/input")
	private WebElement fromCalendar;
	// @FindBy(xpath="//label[text()='Date
	// To']//following-sibling::div//input[@class='MuiInputBase-input MuiInput-input
	// MuiInputBase-inputAdornedEnd']") WebElement toCalendar;
	@FindBy(xpath = "//span[6]//div[1]//div[1]//input[1]")
	private WebElement toCalendar;
	@FindBy(xpath = "//button/span[text()=' Search']")
	private WebElement searchButton;
	@FindBy(xpath = "//button/span[text()=' Reset']")
	private WebElement resetButton;
	@FindBy(xpath = "//div[contains(text(),'3732775454')]")
	private WebElement filterSearch;
	@FindBy(xpath = "//span[text()=' Export']")
	private WebElement Export;

	public TTHistoricalPayments(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void searchPayments() throws Exception {

		// enter a currency
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0, -250);");
		Thread.sleep(2000);
		Actions act = new Actions(driver);
		act.moveToElement(currency).click().build().perform();
		act.moveToElement(currency).sendKeys("AUD").build().perform();
		act.moveToElement(currency).sendKeys(Keys.ARROW_DOWN).build().perform();
		act.moveToElement(currency).sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);

		// enter a bank account
		Thread.sleep(2000);
		act.moveToElement(bankAccount).click().build().perform();
		act.moveToElement(bankAccount).sendKeys("6287").build().perform();
		act.moveToElement(bankAccount).sendKeys(Keys.ARROW_DOWN).click().perform();
		act.moveToElement(bankAccount).sendKeys(Keys.ENTER).click().perform();

		// enter date from
		Thread.sleep(2000);
		act.moveToElement(fromCalendar).click().build().perform();
		act.moveToElement(fromCalendar).sendKeys("01/11/2019").build().perform();
		act.moveToElement(fromCalendar).sendKeys(Keys.ENTER).build().perform();

		// enter date to
		Thread.sleep(2000);
		act.moveToElement(toCalendar).click().build().perform();
		act.moveToElement(toCalendar).sendKeys("01/11/2019").build().perform();
		act.moveToElement(toCalendar).sendKeys(Keys.ENTER).build().perform();

		Thread.sleep(1000);

	}

	public void searchButton() throws Exception {

		waitUtil.untilWebElementIsClickable(driver, searchButton);
		searchButton.click();
		Thread.sleep(2000);

	}

	public void filterSearch() throws Exception {
		// lets now select an account

		waitUtil.untilWebElementVisible(driver, Export);
		Actions act = new Actions(driver);
		act.moveToElement(filterSearch).doubleClick().build().perform();
		act.moveToElement(filterSearch).sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(5000);
		WebElement closeSearch = driver.findElement(By.xpath("//span[contains(text(),'Close')]"));
		act.moveToElement(closeSearch).click().build().perform();
		act.moveToElement(closeSearch).sendKeys(Keys.ENTER).build().perform();

		Thread.sleep(5000);

	}
	// hit reset

	public void resetButton() throws Exception {

		waitUtil.untilWebElementIsClickable(driver, resetButton);
		Thread.sleep(2000);
		resetButton.click();
	}

}
