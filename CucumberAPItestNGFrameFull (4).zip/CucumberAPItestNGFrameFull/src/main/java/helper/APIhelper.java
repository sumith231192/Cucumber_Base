//package helper;
//
//import static javax.swing.text.DefaultStyledDocument.ElementSpec.ContentType;
//import static org.testng.Assert.assertEquals;
//
//import java.io.File;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Collection;
//import java.util.Collections;
//import java.util.List;
//import java.util.Map;
//import java.util.TreeMap;
//
//import org.json.JSONArray;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.support.PageFactory;
//
//import com.fasterxml.jackson.core.type.TypeReference;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.google.gson.Gson;
//import com.google.gson.GsonBuilder;
//
//import static io.restassured.RestAssured.*;
//import static io.restassured.matcher.RestAssuredMatchers.*;
//
//import io.restassured.RestAssured;
//import io.restassured.http.ContentType;
//import io.restassured.response.Response;
//import io.restassured.specification.RequestSpecification;
//import pageObject.TTLoginPage;
//import pojo.Accounts;
//import utility.ConfigFileReader;
//import utility.DriverManager;
//import utility.TestDataReader;
//
//public class APIhelper {
//	WebDriver driver;
//	private DriverManager webDriverManager = new DriverManager();
//
//	private TTLoginPage loginpage = new TTLoginPage(driver);
//	ConfigFileReader configFileReader = new ConfigFileReader();
//	TestDataReader testDataReaderTC = new TestDataReader("TestDataTC");
//	public static Response response;
//	public static String jsonAsString;
//
//	public APIhelper(WebDriver driver) {
//
//		this.driver = driver;
//		PageFactory.initElements(driver, this);
//	}
//
//	public static void setupURL() {
//		// here we setup the default URL and API base path to use throughout the tests
//		RestAssured.baseURI = "https://treasuryterminal-api-beta.fcstone.com";
//		RestAssured.basePath = "/api/accounts";
//	}
//
//	public Response callRidesAPI() {
//		String acctocken = loginpage.getauthcodeForAPI();
//		setupURL();
//		RequestSpecification httpRequest = RestAssured.given().auth().oauth2(acctocken).contentType(ContentType.JSON)
//				.log().all();
//		Response response = httpRequest.get();
//		return response;
//
//	}
//
//	public List<String> jsonToList(Response response) {
//		List<String> jsonResponse = response.jsonPath().getList("$");
//		return jsonResponse;
//
//	}
//
//	public void createJsonFile(String jsonString) {
//		try {
//			FileWriter file = new FileWriter("./src/main/resources/TestData/output.json");
//			file.write(jsonString);
//			file.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	public Object jsonToObject(String key) {
//		ObjectMapper mapper = new ObjectMapper();
//		Map<String, Object> jsonmap = new TreeMap<>();
//		try {
//			jsonmap = mapper.readValue(new File("./src/main/resources/TestData/output.json"),
//					new TypeReference<Map<String, Object>>() {
//					});
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println(jsonmap);
//
//		return jsonmap.get(key);
//
//	}
//
//	public Map<String, Object> jsonToMap(String jsonString) {
//		ObjectMapper mapper = new ObjectMapper();
//		Map<String, Object> jsonmap = new TreeMap<>();
//
//		System.out.println(jsonString);
//
//		return jsonmap;
//
//	}
//
//	public Accounts getAccountDetailsFromPojo(String responseString) {
//		Accounts acc = new Accounts();
//		JSONArray jsonArray = new JSONArray(responseString);
//		// System.out.println(jsonArray.get(0).toString());
//		ArrayList<String> list = new ArrayList<String>();
//		list = convertJsonArrayToList(jsonArray);
//		Collections.shuffle(list);
//
//		String accdata = list.get(0);
//		if (!accdata.isEmpty()) {
//			GsonBuilder builder = new GsonBuilder();
//			builder.setPrettyPrinting();
//
//			Gson gson = builder.create();
//			acc = gson.fromJson(accdata, Accounts.class);
//		} else {
//			assertEquals(true, false, "No data found");
//		}
//
//		return acc;
//
//	}
//
//	public boolean validateSetofdateFromTestDataTC(String data) {
//		Collection<String> valueCollectio = testDataReaderTC.getDataFromTestData().values();
//		if (valueCollectio.contains(data)) {
//			return true;
//		} else {
//			return false;
//		}
//
//	}
//
//	public ArrayList<String> convertJsonArrayToList(JSONArray jsonArray) {
//		ArrayList<String> list = new ArrayList<String>();
//
//		if (jsonArray != null) {
//			int len = jsonArray.length();
//			for (int i = 0; i < len; i++) {
//				list.add(jsonArray.get(i).toString());
//			}
//		}
//		return list;
//	}
//}
