package helper;

import org.junit.Assert;
/*import static org.assertj.core.api.Assertions.assertThat;*/

public class AssertionHelper {
	
	public static void verifyText(String s1, String s2){

		Assert.assertEquals(s1, s1,"veryfing test: "+ s1 + " with "+ s2);
	}
	
	public static void markPass(){
		
		Assert.assertTrue(true);
	}
	
	public static void markPass(String message){
		
		Assert.assertTrue(message, true);
	}
	
	public static void markFail(){
		
		Assert.assertTrue(false);
	}
	
	public static void markFail(String message){
		
		Assert.assertTrue(message,false);
	}
	
	public static void verifyTrue(boolean status){
		Assert.assertTrue(status);
	}
	
	public static void verifyFalse(boolean status){
		Assert.assertFalse(status);
	}
	
	public static void verifyNull(String s1){
//	    Log.info("verify object is null..");
		Assert.assertNull(s1);
	}
	
	public static void verifyNotNull(String s1){
//		Log.info("verify object is not null..");
		Assert.assertNotNull(s1);
	}
	
	public static void fail(){
		Assert.assertTrue(false);
	}
	
	public static void pass(){
		Assert.assertTrue(true);
	}
	
	public static void updateTestStatus(boolean status){
		if(status){
			pass();
		}
		else{
			fail();
		}
	}
	public static void softAssertVerifyText(String s1,String s2) {
		verifyText(s1, s2);
	}
}

