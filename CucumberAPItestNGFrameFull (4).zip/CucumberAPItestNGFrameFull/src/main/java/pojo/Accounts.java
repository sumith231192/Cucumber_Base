package pojo;

import java.util.Date;

public class Accounts {
	public String accountId;
    public String accountName;
    public String accountNumber;
    public boolean segregation;
    public String systemAccount;
    public Object beneficiary;
    public String bank;
    public Object iban;
    public Object bankAddress;
    public String bic;
    public String routingBic;
    public String messagingBic;
    public boolean active;
    public Date deactivationTime;
    public String deactivatedBy;
    public String swiftMessageTime;
    public String uniqueRef;
    public Object cutOffTime;
    public Object dateType;
    public Object routing;
    public String currency;
    public LegalEntity legalEntity;
 LegalEntity LegalEntityObject;


 // Getter Methods 
// public Accounts() {}

 public String getAccountId() {
  return accountId;
 }

 public String getAccountName() {
  return accountName;
 }

 public String getAccountNumber() {
  return accountNumber;
 }

 public boolean getSegregation() {
  return segregation;
 }

 public String getSystemAccount() {
  return systemAccount;
 }


 public String getBank() {
  return bank;
 }
 
 public String getBic() {
  return bic;
 }

 public String getRoutingBic() {
  return routingBic;
 }

 public String getMessagingBic() {
  return messagingBic;
 }

 public boolean getActive() {
  return active;
 }

 
 public String getDeactivatedBy() {
  return deactivatedBy;
 }


 public String getUniqueRef() {
  return uniqueRef;
 }


 public String getCurrency() {
  return currency;
 }

 public LegalEntity getLegalEntity() {
  return LegalEntityObject;
 }

 // Setter Methods 

 public void setAccountId(String accountId) {
  this.accountId = accountId;
 }

 public void setAccountName(String accountName) {
  this.accountName = accountName;
 }

 public void setAccountNumber(String accountNumber) {
  this.accountNumber = accountNumber;
 }

 public void setSegregation(boolean segregation) {
  this.segregation = segregation;
 }

 public void setSystemAccount(String systemAccount) {
  this.systemAccount = systemAccount;
 }

 public void setBeneficiary(String beneficiary) {
  this.beneficiary = beneficiary;
 }

 public void setBank(String bank) {
  this.bank = bank;
 }

 public void setIban(String iban) {
  this.iban = iban;
 }

 public void setBankAddress(String bankAddress) {
  this.bankAddress = bankAddress;
 }

 public void setBic(String bic) {
  this.bic = bic;
 }

 public void setRoutingBic(String routingBic) {
  this.routingBic = routingBic;
 }

 public void setMessagingBic(String messagingBic) {
  this.messagingBic = messagingBic;
 }

 public void setActive(boolean active) {
  this.active = active;
 }

 

 public void setDeactivatedBy(String deactivatedBy) {
  this.deactivatedBy = deactivatedBy;
 }

 public void setSwiftMessageTime(String swiftMessageTime) {
  this.swiftMessageTime = swiftMessageTime;
 }

 public void setUniqueRef(String uniqueRef) {
  this.uniqueRef = uniqueRef;
 }

 public void setCutOffTime(String cutOffTime) {
  this.cutOffTime = cutOffTime;
 }

 public void setDateType(String dateType) {
  this.dateType = dateType;
 }

 public void setRouting(String routing) {
  this.routing = routing;
 }

 public void setCurrency(String currency) {
  this.currency = currency;
 }

 public void setLegalEntity(LegalEntity legalEntityObject) {
  this.LegalEntityObject = legalEntityObject;
 }
}

