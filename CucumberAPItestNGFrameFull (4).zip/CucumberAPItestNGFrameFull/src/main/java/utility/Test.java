package utility;

public class Test {
	
	 public static void main(String []args){
	       String str = "Sumith";
	       
	     String result = "";
	     
	     String[] sarr = str.split("");
	     int size = sarr.length;
	     for( int k = size -1;k>=0;k--)
	     {
	         result = result+sarr[k];
	         
	     }
	     if(result.equals(str))
	     {
	         System.out.println("Its a palentRoem");
	     }
	     else
	     {
	         System.out.println("Its Not a palentRoem");
	     }
	      
	     
	      
	     }

}
