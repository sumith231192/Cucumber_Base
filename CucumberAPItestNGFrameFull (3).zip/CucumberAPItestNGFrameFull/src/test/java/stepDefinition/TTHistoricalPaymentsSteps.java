package stepDefinition;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.TTHistoricalEOD;
import pageObject.TTHistoricalPayments;
import pageObject.TTHomePage;
import pageObject.TTLoginPage;
import utility.DriverManager;

public class TTHistoricalPaymentsSteps {

	private WebDriver driver = DriverManager.getInstace().getDriver();

	TTLoginPage ttLoginPage = null;
	TTHomePage ttHomePage = null;
	TTHistoricalEOD ttHistoricalEOD = null;
	TTHistoricalPayments ttHistoricalPayments =null;

	@Given("User has navigated to Historical Payments")
	public void user_has_navigated_to_historical_payments() throws Exception {
		ttLoginPage = new TTLoginPage(driver);
		ttLoginPage.navigateToTTHomepage();
		TTHomePage ttHomePage = new TTHomePage(driver);
		ttHomePage.navigateToTTHistoricalPayments();

	}

	@When("User enters details on Search Tab")
	public void user_enters_details_in_search_tab() throws Exception {
		
		ttHistoricalPayments = new TTHistoricalPayments(driver);
		ttHistoricalPayments.searchPayments();
	}

	@Then("Payment transaction should be displayed when search button clicked")
	public void payment_transction_should_be_displayed_when_search_button_clicked() throws Exception {
		ttHistoricalPayments.searchButton();

	}

	@Then("User selects account and view popup")
	public void user_selects_account_and_view_popup() throws Exception {
		ttHistoricalPayments.filterSearch();

	}

	@Then("Screen should be refreshed")
	public void screen_should_be_refreshed() throws Exception {
		ttHistoricalPayments.resetButton();

	}

}
