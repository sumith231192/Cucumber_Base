package helper;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import utility.ConfigFileReader;

/*
 * 
 * This  Utility under Helper package is used to add wait time in the web page 
 * 
 * 
 */
public class WaitUtil {
	ConfigFileReader configFileReader = new ConfigFileReader();

	public FluentWait<WebDriver> fluentWait(WebDriver driver) {

		FluentWait<WebDriver> waitFluent = new FluentWait<WebDriver>(driver)
				.withTimeout(configFileReader.getWebElemntWaitTime(), TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);

		return waitFluent;
	}

	/**
	 * Implicitly wait using J query
	 * 
	 * @param WedDriver
	 * 
	 * 
	 */
	public void untilJqueryIsDone(WebDriver driver) {
		untilJqueryIsDone(driver, configFileReader.getImplicitlyWait());
	}

	/**
	 * Thread sleep
	 * 
	 * @param Int
	 *            Seconds
	 * 
	 * 
	 */
	public void sleepSeconds(Integer seconds) {

		try {
			TimeUnit.SECONDS.sleep(seconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Implicitly wait using J query
	 * 
	 * @param WedDriver,Log
	 *            time in seconds
	 * 
	 * 
	 */
	public void untilJqueryIsDone(final WebDriver driver, Long timeoutInSeconds) {
		until(driver, new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {
				Boolean isJqueryCallDone = (Boolean) ((JavascriptExecutor) driver)
						.executeScript("return jQuery.active==0");

				return isJqueryCallDone;
			}
		}, timeoutInSeconds);
	}

	/**
	 * Implicitly wait till page load complete
	 * 
	 * @param WedDriver
	 * 
	 * 
	 */
	public void untilPageLoadComplete(WebDriver driver) {

		untilPageLoadComplete(driver, (int) configFileReader.getImplicitlyWait());
	}

	/**
	 * wait till the page load complete
	 * 
	 * @param WedDriver,int
	 *            time interval
	 * 
	 * 
	 */
	public void untilPageLoadComplete(final WebDriver driver, int timrintervel) {
		until(driver, new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {
				Boolean isPageLoaded = (Boolean) "complete"
						.equals(((JavascriptExecutor) driver).executeScript("return document.readyState"));

				return isPageLoaded;
			}
		}, (long) timrintervel);
	}

	/**
	 * Wait till your customized condition is full filled Wait time is read from
	 * config file
	 * 
	 * @param WedDriver,Condetion
	 * 
	 * 
	 */
	public void until(WebDriver driver, Function<WebDriver, Boolean> waitCondition) {
		until(driver, waitCondition, configFileReader.getImplicitlyWait());
	}

	/**
	 * Explicit wait till untilWebElementVisible
	 * 
	 * @param WedDriver,
	 *            WebElement
	 * 
	 * 
	 */
	public void untilWebElementVisible(WebDriver driver, WebElement webElement) {
		WebDriverWait wait = new WebDriverWait(driver, configFileReader.getWebElemntWaitTime());
		wait.until(ExpectedConditions.visibilityOf(webElement));

	}

	/**
	 * Explicit wait till untilWebElementIsClickable
	 * 
	 * @param WedDriver,
	 *            WebElement
	 * 
	 * 
	 */
	public void untilWebElementIsClickable(WebDriver driver, WebElement webElement) {
		WebDriverWait wait = new WebDriverWait(driver, configFileReader.getWebElemntWaitTime());
		wait.until(ExpectedConditions.elementToBeClickable(webElement));

	}

	/**
	 * Explicit wait till untilWebElementStale
	 * 
	 * @param WedDriver,
	 *            WebElement
	 * 
	 * 
	 */
	public void untilWebElementStale(WebDriver driver, WebElement webElement) {
		WebDriverWait wait = new WebDriverWait(driver, configFileReader.getWebElemntWaitTime());
		wait.until(ExpectedConditions.stalenessOf(webElement));
	}

	/**
	 * Wait till your customized condition is full filled Wait time is read from
	 * cutomised time
	 * 
	 * @param WedDriver,Condetion,
	 *            Long timeoutInSeconds
	 * 
	 * 
	 */
	private void until(WebDriver driver, Function<WebDriver, Boolean> waitCondition, Long timeoutInSeconds) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, timeoutInSeconds);
		webDriverWait.withTimeout(timeoutInSeconds, TimeUnit.SECONDS);
		try {
			webDriverWait.until(waitCondition);
		} catch (Exception e) {
			Reporter.log(e.getMessage());
		}
	}

	/**
	 * Time unit sleep
	 * 
	 * @param int
	 *            Time in seconds
	 * 
	 * 
	 */
	public void timeUnitSleep(int Seconds) throws InterruptedException {
		try {
			TimeUnit.SECONDS.sleep(Seconds);
		} catch (Exception e) {

		}

	}
	
	
	public void untilWebElementInStale(WebDriver driver, WebElement webElement) {
		WebDriverWait wait = new WebDriverWait(driver, configFileReader.getWebElemntWaitTime());
		wait.until(ExpectedConditions.refreshed(ExpectedConditions.stalenessOf(webElement)));

	}

	
}