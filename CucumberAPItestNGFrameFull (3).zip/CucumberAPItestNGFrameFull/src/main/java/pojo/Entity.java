package pojo;

import java.util.ArrayList;
import java.util.List;
public class Entity
{
    private int id;

    private String entity;

    private List<String> businessGroups;

    private String backOfficeCode;

    private String sharedBackOfficeCode;

    private String country;
    
    public Entity() {
		
	}

    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }
    public void setEntity(String entity){
        this.entity = entity;
    }
    public String getEntity(){
        return this.entity;
    }
    public void setBusinessGroups(List<String> businessGroups){
        this.businessGroups = businessGroups;
    }
    public List<String> getBusinessGroups(){
        return this.businessGroups;
    }
    public void setBackOfficeCode(String backOfficeCode){
        this.backOfficeCode = backOfficeCode;
    }
    public String getBackOfficeCode(){
        return this.backOfficeCode;
    }
    public void setSharedBackOfficeCode(String sharedBackOfficeCode){
        this.sharedBackOfficeCode = sharedBackOfficeCode;
    }
    public String getSharedBackOfficeCode(){
        return this.sharedBackOfficeCode;
    }
    public void setCountry(String country){
        this.country = country;
    }
    public String getCountry(){
        return this.country;
    }
}
