package utility;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class ConfigFileReader {

	private Properties properties;
	private final String propertyFilePath = "./src/main/resources/Configs/Configeration.properties";
	FileOutputStream out;

	public ConfigFileReader() {
		BufferedReader reader;

		try {
			reader = new BufferedReader(new FileReader(propertyFilePath));
			properties = new Properties();
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
		}
	}
	public void  setConfigProperty(String key, String value)  {
		
		if (key != null)
			try {
				if(value != null)
				{
				out = new FileOutputStream(propertyFilePath);
				properties.setProperty(key, value);
				properties.store(out, null);
				out.close();
				}
				
			} catch (IOException e) {
				
			} finally {
				
			}
		else
			throw new RuntimeException("driverPath not specified in the Configuration.properties file.");
	}
	public String getAccessToken() {
		String vaue = properties.getProperty("accessToken");
		if (vaue != null)
			return vaue;
		else
			throw new RuntimeException("accessToken not specified in the Configuration.properties file.");
	}
	
	public String getaccessTokenTimeStanp() {
		String vaue = properties.getProperty("accessTokenTimeStamp");
		if (vaue != null)
			return vaue;
		else
			throw new RuntimeException("accessTokenTimeStamp not specified in the Configuration.properties file.");
	}

	public String getChromeDriverPath() {
		String driverPath = properties.getProperty("CHROMEDRIVERPATH");
		if (driverPath != null)
			return driverPath;
		else
			throw new RuntimeException("driverPath not specified in the Configuration.properties file.");
	}

	public String getIEDriverPath() {
		String driverPath = properties.getProperty("IEDRIVERPATH");
		if (driverPath != null)
			return driverPath;
		else
			throw new RuntimeException("driverPath not specified in the Configuration.properties file.");
	}
	public String getExtendReportConfigPath(){
		String reportConfigPath = properties.getProperty("EXTEND_REP_PATH");
		if(reportConfigPath!= null) return reportConfigPath;
		else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");		
	}

	public long getImplicitlyWait() {
		String implicitlyWait = properties.getProperty("IMPLICITLYWAIT");
		if (implicitlyWait != null)
			return Long.parseLong(implicitlyWait);
		else
			throw new RuntimeException("implicitlyWait not specified in the Configuration.properties file.");
	}

	public long getWebElemntWaitTime() {
		String ElemntWaitTime = properties.getProperty("WAITFORELEMENT");
		if (ElemntWaitTime != null)
			return Long.parseLong(ElemntWaitTime);
		else
			throw new RuntimeException("WAITFORELEMENT Wait not specified in the Configuration.properties file.");
	}

	public String getApplicationUrl() {
		String url = properties.getProperty("URL");

		if (url != null)
			return url;
		else
			throw new RuntimeException("url not specified in the Configuration.properties file.");
	}
	
	public String getSearchValue() {
		String value = properties.getProperty("SEARCH_VALUE");

		if (value != null)
			return value;
		else
			throw new RuntimeException("SEARCH_VALUE is not specified in the Configuration.properties file.");
	}

	public String getUserId() {
		String value = properties.getProperty("USER_ID");

		if (value != null)
			return value;
		else
			throw new RuntimeException("USER_ID is not specified in the Configuration.properties file.");
	}

	
	
	public String getPassword() {
		String value = properties.getProperty("PASSWORD");

		if (value != null)
			return value;
		else
			throw new RuntimeException("PASSWORD is not specified in the Configuration.properties file.");
	}
	public String getTagName() {
		String value = properties.getProperty("TAG_NAME");

		if (value != null)
			return value;
		else
			throw new RuntimeException("TAG_NAME is not specified in the Configuration.properties file.");
	}
	
	public String getBrowser() {
		String value = properties.getProperty("BROWSER");

		if (value != null)
			return value;
		else
			throw new RuntimeException("BROWSER is not specified in the Configuration.properties file.");
	}
	
	public Map<String, String> getDataFromConfig() {

		 HashMap<String, String> mymap = new HashMap<String, String>();
		 for (String key : properties.stringPropertyNames()) {
		  String value = properties.getProperty(key);
		  mymap.put(key, value);
		 }

		 return mymap;

		}



	
}