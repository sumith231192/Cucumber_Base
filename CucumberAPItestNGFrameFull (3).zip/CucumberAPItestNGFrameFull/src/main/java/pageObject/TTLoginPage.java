package pageObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.LocalStorage;
import helper.WaitUtil;
import utility.ConfigFileReader;
import utility.DriverManager;

public class TTLoginPage {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	WaitUtil waitUtil = new WaitUtil();
	DriverManager webDriverManager = new DriverManager();

	@FindBy(xpath = "//input[@name='Username']")
	private WebElement username;
	@FindBy(xpath = "//input[@name='Password']")
	private WebElement password;
	@FindBy(xpath = "//button[text()='Sign In']")
	private WebElement signIn;
	 

	@FindBy(xpath = "//div[@class= 'MuiBox-root jss46 jss44']/img")
	private WebElement TTimgLink;

	public TTLoginPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void navigateToTTHomepage() {
		driver.get(configFileReader.getApplicationUrl());
		waitUtil.untilWebElementIsClickable(driver, TTimgLink);

		TTimgLink.click();
		waitUtil.untilPageLoadComplete(driver);
	}

	public Date addHoursToJavaUtilDate(Date date, int hours) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.HOUR_OF_DAY, hours);
		return calendar.getTime();
	}

	// This Util Checks that current date is greater than the date in config(12hr +
	// date when auth is took) file as the auth code is valid for 12 hours
	public String getauthcodeForAPI() {
		Date datefromconfig = null;
		Date datefromconfigdate= null;
		Date vlaidTill = null;
		Date currentdate = new Date();
		Date today = null;
		try {
			SimpleDateFormat actDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			SimpleDateFormat actDateFormatdate = new SimpleDateFormat("yyyy/MM/dd");
			today = actDateFormatdate.parse(actDateFormat.format(currentdate));
			datefromconfig = actDateFormat.parse(configFileReader.getaccessTokenTimeStanp());
			datefromconfigdate = actDateFormatdate.parse(configFileReader.getaccessTokenTimeStanp());
			vlaidTill = addHoursToJavaUtilDate(datefromconfig, 12);
		} catch (ParseException e) {

		}

		String accessToken = configFileReader.getAccessToken();
		if (!datefromconfig.before(vlaidTill)||!datefromconfigdate.equals(today)) {
			navigateToTTHomepage();
			LocalStorage localStorage = new LocalStorage(driver);
			accessToken = localStorage.getItemFromLocalStorage("accessToken");
			configFileReader.setConfigProperty("accessToken", accessToken);
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			LocalDateTime now = LocalDateTime.now();
			configFileReader.setConfigProperty("accessTokenTimeStamp", dtf.format(now).toString());
			driver.close();
		}
		/*else {
			webDriverManager.killDriver();
		}*/
		
		return accessToken;

	}
}
